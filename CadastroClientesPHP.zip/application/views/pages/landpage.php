
<div class="container">
  <div class="row">
    <div class="col-md-12 text-center mb-4">
      <h1>Dashboard</h1>
    </div>
    <div class="col-md-3 text-center"></div>
    <div class="col-md-2 text-center">
      <a class="nav-item nav-link" href="<?= BASE_URL.'clientes' ?>">
      <img src='<?= DESIGN_PATH ?>img/cliente.png' style='max-width: 100px;'/>
      <h4 class='text-dark'>Clientes</h4></a>
    </div>
    <div class="col-md-2 text-center">
      <a class="nav-item nav-link" href="<?= BASE_URL.'pedidos' ?>">
      <img src='<?= DESIGN_PATH ?>img/pedidos.png'  style='max-width: 100px;'/>
      <h4 class='text-dark'>Pedidos</h4></a>
    </div>
    <div class="col-md-2 text-center">
      <a class="nav-item nav-link" href="<?= BASE_URL.'relatorio' ?>">
      <img src='<?= DESIGN_PATH ?>img/relatorio.png'  style='max-width: 100px;'/>
      <h4 class='text-dark'>Relatorios</h4></a>
    </div>
  </div>
</div>
