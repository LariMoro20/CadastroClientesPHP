<header class='header-top text-center margin-bt20'>
    <img class='logo' src='<?= DESIGN_PATH ?>img/logo.png'/><h1 class='text-light'>Rita's Cookies</h1>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?= BASE_URL?>">Painel</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link active" href="<?= BASE_URL?>">Inicial <span class="sr-only">(current)</span></a>
      <a class="nav-item nav-link" href="<?= BASE_URL.'clientes' ?>">Clientes</a>
      <a class="nav-item nav-link" href="<?= BASE_URL.'pedidos' ?>">Pedidos</a>
      <a class="nav-item nav-link " href="<?= BASE_URL.'Relatorio' ?>">Relatório</a>
    </div>
  </div>
</nav>
</header>